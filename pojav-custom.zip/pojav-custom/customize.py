#!/usr/bin/env python3
"""Personnalise un clone de PojavLauncher.
Usage:  python3 customize.py /chemin/vers/PojavLauncher
Modifie: nom de l'app, applicationId, et copie AutoJoin.java dans le projet.
"""
import re, sys, shutil
from pathlib import Path

# ====== A MODIFIER ======
APP_NAME = "MonLauncher"
APP_ID = "com.monlauncher.mc"
SERVER_HOST = "127.0.0.1"   # IP de ton serveur
SERVER_PORT = "25565"
DEFAULT_USERNAME = "Joueur"
# ========================

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
mod = root / "app_pojavlauncher"
if not mod.exists():
    sys.exit("Dossier app_pojavlauncher introuvable : donne le chemin du repo PojavLauncher.")

def edit(path, fn, label):
    if not path.exists():
        print(f"[!] {label}: {path} introuvable"); return
    old = path.read_text(encoding="utf-8")
    new = fn(old)
    if new == old:
        print(f"[!] {label}: aucune modification (motif non trouve)")
    else:
        path.write_text(new, encoding="utf-8"); print(f"[ok] {label}")

# 1. Nom de l'app
edit(mod / "src/main/res/values/strings.xml",
     lambda s: re.sub(r'(<string name="app_name"[^>]*>)[^<]*(</string>)', rf'\g<1>{APP_NAME}\g<2>', s),
     "nom de l'app")

# 2. applicationId
edit(mod / "build.gradle",
     lambda s: re.sub(r'(applicationId\s*=?\s*)["\']net\.kdt\.pojavlaunch["\']', rf'\g<1>"{APP_ID}"', s),
     "applicationId")

# 3. AutoJoin.java
pkg_dir = mod / "src/main/java/net/kdt/pojavlaunch"
if pkg_dir.exists():
    src = Path(__file__).parent / "AutoJoin.java"
    txt = (src.read_text(encoding="utf-8")
           .replace("__HOST__", SERVER_HOST).replace("__PORT__", SERVER_PORT)
           .replace("__USER__", DEFAULT_USERNAME))
    (pkg_dir / "AutoJoin.java").write_text(txt, encoding="utf-8")
    print("[ok] AutoJoin.java copie")
else:
    print("[!] dossier java net/kdt/pojavlaunch introuvable")

print("\nEtape manuelle restante : voir README.md (section 'Brancher AutoJoin').")
