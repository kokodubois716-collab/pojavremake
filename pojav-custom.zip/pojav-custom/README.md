# Fork personnalisé de PojavLauncher (compte offline + serveur préconfiguré)

## 1. Récupérer la base
    git clone https://github.com/PojavLauncherTeam/PojavLauncher.git
    cd PojavLauncher
    git submodule update --init --recursive   # si le repo en utilise

## 2. Appliquer la personnalisation
Édite les constantes en haut de `customize.py` (nom, package, IP/port, pseudo), puis :

    python3 customize.py /chemin/vers/PojavLauncher

Le script change le nom de l'app, l'`applicationId` et ajoute `AutoJoin.java`.
Chaque ligne affiche `[ok]` ou `[!]` : si un `[!]` apparaît, le motif a changé
dans la version du repo et il faut faire la modif à la main.

## 3. Brancher AutoJoin (manuel, 1 ligne)
Dans `app_pojavlauncher/src/main/java/net/kdt/pojavlaunch/Tools.java`, trouve la
méthode qui construit les arguments du jeu (cherche `getMinecraftClientArgs`)
et enveloppe son résultat :

    return AutoJoin.apply(argsDuJeu);

(si elle retourne un `String[]`; sinon convertis en tableau avant).

## 4. Compte offline
PojavLauncher propose déjà « Compte local » sur l'écran de connexion :
choisis un pseudo et c'est un compte offline. Rien à coder.
Ton serveur doit être en `online-mode=false`.

## 5. Compiler en APK
Dans Android Studio, ouvre le dossier, laisse Gradle synchroniser, puis
Build > Build APK(s). Ou en ligne de commande :

    ./scripts/languagelist_updater.sh   # si le script existe
    ./gradlew :app_pojavlauncher:assembleDebug

L'APK sort dans `app_pojavlauncher/build/outputs/apk/debug/`.
Pojav est sous licence LGPL-3 : garde la licence et mentionne le projet d'origine.

## Limites
Je n'ai pas pu tester contre la dernière version du repo (pas d'accès réseau ici),
donc les chemins ou noms de méthodes peuvent avoir légèrement changé.
