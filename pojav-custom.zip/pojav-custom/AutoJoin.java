package net.kdt.pojavlaunch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Ajoute la connexion automatique au serveur aux arguments du jeu. */
public final class AutoJoin {
    public static final String HOST = "__HOST__";
    public static final String PORT = "__PORT__";
    public static final String DEFAULT_USERNAME = "__USER__";

    private AutoJoin() {}

    /** Retourne les arguments du jeu + la connexion auto (evite les doublons). */
    public static String[] apply(String[] gameArgs) {
        List<String> args = new ArrayList<>(Arrays.asList(gameArgs));
        if (args.contains("--server") || args.contains("--quickPlayMultiplayer")) return gameArgs;
        // Ancien style (toutes versions <= 1.19.x) : --server / --port
        // Pour 1.20+, on peut utiliser : --quickPlayMultiplayer HOST:PORT
        args.add("--server"); args.add(HOST);
        args.add("--port");   args.add(PORT);
        return args.toArray(new String[0]);
    }
}
